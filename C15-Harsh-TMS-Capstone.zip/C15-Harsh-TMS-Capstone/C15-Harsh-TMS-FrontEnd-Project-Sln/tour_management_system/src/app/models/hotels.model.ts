export class hotels {
  id: string = "";
  name: string = ""; 
  location: string = "";
  rating: string = "";
  price: string = "";
  rooms: number = 0; 
}
